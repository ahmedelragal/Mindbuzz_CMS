<link rel="shortcut icon" href="{{ asset('images/favicon.png') }}">
<title>Dashboard | Mindbuzz </title>
<link rel="stylesheet" href="{{ asset('assets/css/dashlitee5ca.css?ver=3.2.3') }}">
<link id="skin-default" rel="stylesheet" href="{{ asset('assets/css/themee5ca.css?ver=3.2.3') }}">
<link id="skin-default" rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-91615293-4"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-91615293-4');
</script>
